/* ===== basic storage ===== */
let imgs = [];

/* ===== login system ===== */
function login() {
let email = document.getElementById("email").value.trim();
let pass = document.getElementById("password").value.trim();

if (email === "" || pass === "") {
alert("enter details first");
return;
}

if (!email.includes("@")) {
alert("invalid email bro");
return;
}

document.getElementById("loginBox").style.display = "none";
document.getElementById("appBox").style.display = "block";
document.getElementById("navbar").style.display = "flex";

document.getElementById("userName").innerText = "👤 " + email.split("@")[0];
document.getElementById("userEmail").innerText = "📧 " + email;
}

/* ===== register ===== */
function register() {
let email = document.getElementById("regEmail").value.trim();
let pass = document.getElementById("regPass").value.trim();

if (!email || !pass) {
alert("fill everything");
return;
}

if (pass.length < 6) {
alert("password too short");
return;
}

alert("account created 👍");
showLogin();
}

function showRegister() {
document.getElementById("loginBox").style.display = "none";
document.getElementById("registerBox").style.display = "block";
}

function showLogin() {
document.getElementById("registerBox").style.display = "none";
document.getElementById("loginBox").style.display = "block";
}

/* ===== menu ===== */
function toggleMenu() {
let m = document.getElementById("menu");
if (m.style.display === "block") {
m.style.display = "none";
} else {
m.style.display = "block";
}
}

/* ===== image upload ===== */
document.getElementById("imageInput").addEventListener("change", function () {
let files = this.files;

for (let i = 0; i < files.length; i++) {
let reader = new FileReader();

```
reader.onload = function (e) {
  imgs.push(e.target.result);
  showImgs();
};

reader.readAsDataURL(files[i]);
```

}
});

function showImgs() {
let box = document.getElementById("previewBox");
box.innerHTML = "";

for (let i = 0; i < imgs.length; i++) {
box.innerHTML += `       <div class="preview-img">         <img src="${imgs[i]}">         <span onclick="removeImg(${i})">x</span>       </div>
    `;
}
}

function removeImg(i) {
imgs.splice(i, 1);
showImgs();
}

/* ===== main logic ===== */
function analyze() {
let txt = document.getElementById("text").value.toLowerCase();

if (txt === "" && imgs.length === 0) {
alert("add something first");
return;
}

let risk = "LOW";
let percent = 20;
let msg = "seems fine";

// high risk words
if (
txt.includes("leak") ||
txt.includes("hack") ||
txt.includes("breach") ||
txt.includes("sell data") ||
imgs.length > 0
) {
risk = "HIGH";
percent = 90;
msg = "danger stuff detected";
}

// medium risk
else if (
txt.includes("share") ||
txt.includes("third party") ||
txt.includes("tracking") ||
txt.includes("store data")
) {
risk = "MEDIUM";
percent = 60;
msg = "check properly, not fully safe";
}

document.getElementById("result").style.display = "block";
document.getElementById("riskText").innerText = "Risk Level: " + risk;

let bar = document.getElementById("fill");
bar.style.width = percent + "%";

if (risk === "HIGH") {
bar.style.background = "red";
} else if (risk === "MEDIUM") {
bar.style.background = "orange";
} else {
bar.style.background = "green";
}

document.getElementById("summary").innerText = msg;
}
