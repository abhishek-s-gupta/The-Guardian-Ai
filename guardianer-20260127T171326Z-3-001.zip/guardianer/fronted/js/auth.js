function login() {
  const email = document.getElementById("email").value;
  const pass = document.getElementById("password").value;

  if (!email || !pass) {
    alert("Please enter email and password");
    return;
  }

  document.getElementById("loginBox").style.display = "none";
  document.getElementById("appBox").style.display = "block";
}

function showRegister() {
  alert("Registration successful!");
}
