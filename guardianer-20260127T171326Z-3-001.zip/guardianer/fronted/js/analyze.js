// IMAGE PREVIEW
document.getElementById("imageInput").addEventListener("change", function () {
  const file = this.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    const img = document.getElementById("preview");
    img.src = reader.result;
    img.style.display = "block";
  };
  reader.readAsDataURL(file);
});

// ANALYZE FUNCTION
async function analyze() {
  const text = document.getElementById("text").value;

  if (!text) {
    alert("Enter text or upload image");
    return;
  }

  const res = await fetch("http://localhost:5000/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });

  const data = await res.json();

  document.getElementById("resultBox").style.display = "block";

  let percent = 30;
  let color = "#22c55e";

  if (data.risk === "MEDIUM") {
    percent = 60;
    color = "#facc15";
  }

  if (data.risk === "HIGH") {
    percent = 90;
    color = "#ef4444";
  }

  document.getElementById("riskFill").style.width = percent + "%";
  document.getElementById("riskFill").style.background = color;
  document.getElementById("riskText").innerText =
    "Risk Level: " + data.risk;
  document.getElementById("summary").innerText = data.summary;
}
