document.getElementById("imageInput")?.addEventListener("change", function () {
  const file = this.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    const img = document.getElementById("preview");
    img.src = reader.result;
    img.style.display = "block";
  };
  reader.readAsDataURL(file);
});
