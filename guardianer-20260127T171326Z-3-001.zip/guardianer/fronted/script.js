/* =========================
   GLOBAL VARIABLES
========================= */
let images = [];

/* =========================
   LOGIN / REGISTER
========================= */
function login() {
  const email = document.getElementById("email").value.trim();
  const pass = document.getElementById("password").value.trim();

  if (!email || !pass) {
    alert("Please enter email and password");
    return;
  }

  if (!email.includes("@")) {
    alert("Enter a valid email");
    return;
  }

  document.getElementById("loginBox").style.display = "none";
  document.getElementById("appBox").style.display = "block";
  document.getElementById("navbar").style.display = "flex";

  document.getElementById("userName").innerText = "👤 " + email.split("@")[0];
  document.getElementById("userEmail").innerText = "📧 " + email;
}

function register() {
  const email = document.getElementById("regEmail").value.trim();
  const pass = document.getElementById("regPass").value.trim();

  if (!email || !pass) {
    alert("Please fill all fields");
    return;
  }

  if (pass.length < 6) {
    alert("Password must be at least 6 characters");
    return;
  }

  alert("Account created successfully! Now login.");
  showLogin();
}

function showRegister() {
  document.getElementById("loginBox").style.display = "none";
  document.getElementById("registerBox").style.display = "block";
}

function showLogin() {
  document.getElementById("registerBox").style.display = "none";
  document.getElementById("loginBox").style.display = "block";
}


/* =========================
   PROFILE MENU
========================= */
function toggleMenu() {
  const menu = document.getElementById("menu");
  menu.style.display = menu.style.display === "block" ? "none" : "block";
}

/* =========================
   IMAGE UPLOAD
========================= */
document.getElementById("imageInput").addEventListener("change", function () {
  const files = Array.from(this.files);

  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      images.push(reader.result);
      renderImages();
    };
    reader.readAsDataURL(file);
  });
});

function renderImages() {
  const box = document.getElementById("previewBox");
  box.innerHTML = "";

  images.forEach((img, index) => {
    box.innerHTML += `
      <div class="preview-img">
        <img src="${img}">
        <span class="remove" onclick="removeImage(${index})">×</span>
      </div>
    `;
  });
}

function removeImage(index) {
  images.splice(index, 1);
  renderImages();
}

/* =========================
   ANALYZE FUNCTION
========================= */
function analyze() {
  const text = document.getElementById("text").value.toLowerCase();

  if (!text && images.length === 0) {
    alert("Please add text or image first");
    return;
  }

  let risk = "LOW";
  let percent = 30;
  let summary = "This document looks safe.";

  if (
    text.includes("share") ||
    text.includes("sell") ||
    text.includes("terminate") ||
    images.length > 0
  ) {
    risk = "HIGH";
    percent = 90;
    summary = "This document may contain risky or harmful clauses.";
  }

  document.getElementById("result").style.display = "block";
  document.getElementById("riskText").innerText = "Risk Level: " + risk;

  const fill = document.getElementById("fill");
  fill.style.width = percent + "%";
  fill.style.background = risk === "HIGH" ? "red" : "green";

  document.getElementById("summary").innerText = summary;
}
document.getElementById("imageInput").addEventListener("change", function () {
  const file = this.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    document.getElementById("previewBox").innerHTML =
      `<img src="${reader.result}" class="preview-img">`;
  };
  reader.readAsDataURL(file);
});
document.getElementById("imageInput").addEventListener("change", function () {
  const file = this.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    document.getElementById("previewBox").innerHTML =
      `<img src="${reader.result}" class="preview-img">`;
  };
  reader.readAsDataURL(file);
});

