import express from "express";
import multer from "multer";
import Tesseract from "tesseract.js";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

const upload = multer();

app.post("/analyze", upload.single("image"), async (req, res) => {
  let text = req.body.text || "";
  let extracted = "";

  if (req.file) {
    const result = await Tesseract.recognize(
      req.file.buffer,
      "eng"
    );
    extracted = result.data.text;
  }

  const finalText = (text + " " + extracted).toLowerCase();

  let risk = "LOW";
  if (
    finalText.includes("share") ||
    finalText.includes("sell") ||
    finalText.includes("terminate")
  ) {
    risk = "HIGH";
  }

  res.json({
    risk,
    text: extracted
  });
});

app.listen(5000, () => console.log("Server running on 5000"));
